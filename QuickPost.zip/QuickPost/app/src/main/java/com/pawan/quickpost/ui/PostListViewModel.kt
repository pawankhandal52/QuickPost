package com.pawan.quickpost.ui

import android.view.View
import androidx.lifecycle.MutableLiveData
import com.pawan.quickpost.base.BaseViewModel
import com.pawan.quickpost.network.ApiList
import io.reactivex.Scheduler
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import javax.inject.Inject

/**
 * Created by Pawan Kumar Sharma on 14-Sep-19.
 * Fleeca India Pvt Ltd
 * Android Developer
 * android_developer1@fleeca.in
 * +917737947610
 */
class PostListViewModel:BaseViewModel() {

    @Inject
    lateinit var postApi:ApiList

    private lateinit var subscription: Disposable
    private val loadingBar:MutableLiveData<Int> = MutableLiveData()

    init {
        loadPost()
    }

    private fun loadPost(){
        subscription =  postApi.getPosts()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe{onRetrievePostListStart()}
            .doOnTerminate{onRetrievePostListFinish()}
            .subscribe({
                onRetrievePostListSuccess()
            },{
                onRetrievePostListError()
            })

    }

    private fun onRetrievePostListError() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    private fun onRetrievePostListSuccess() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    private fun onRetrievePostListFinish() {
        loadingBar.value = View.GONE

    }

    private fun onRetrievePostListStart() {
        loadingBar.value = View.VISIBLE
    }


}