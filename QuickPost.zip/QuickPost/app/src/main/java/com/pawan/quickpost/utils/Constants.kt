package com.pawan.quickpost.utils

/**
 * Created by Pawan Kumar Sharma on 14-Sep-19.
 * Fleeca India Pvt Ltd
 * Android Developer
 * android_developer1@fleeca.in
 * +917737947610
 */

const val BASE_URL: String = "https://jsonplaceholder.typicode.com"
